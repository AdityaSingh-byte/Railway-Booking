import React from 'react'
import './Cards.css'
import { MdCurrencyRupee } from "react-icons/md";
const ClassCard = ({ classInfo }) => {
  return (
    
     <div className="class-card">
      <h3>{classInfo.Class}</h3>
      <p> <span style={{color:"green"}}>AVL</span> {classInfo.Seats}</p>
        <div><MdCurrencyRupee />{classInfo.Price}</div>
    </div>
   
  )
}

export default ClassCard
