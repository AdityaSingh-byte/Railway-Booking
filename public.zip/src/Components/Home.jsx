import React from 'react'

const Home = () => {
  return (
    <div>
      Hello
    </div>
  )
}

export default Home
